﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;
using Utilities;

namespace Social_Networking_Site
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        } // end method

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            // clear the error message
            lblErrorMsg1.Text = "";
            lblErrorMsg2.Text = "";
            // call method to check user ID
            GetUserID();
            // call method to check login
            GetLogin();
        } // end method

        // method to retrieve the user ID (email) from database
        public void GetUserID()
        {
            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_GetUserID";

            SqlParameter inputParameter = new SqlParameter("@email", txtLoginID.Text);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            DataSet myDataSet = db.GetDataSetUsingCmdObj(objCommand);
            if (myDataSet.Tables[0].Rows.Count != 1)
            {
                lblErrorMsg1.Text = "Invalid User Name!";
            }

            db.CloseConnection();
        } // end method

        // method to retrieve the user ID (email) from database
        public void GetLogin()
        {
            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_Login";

            SqlParameter inputParameter = new SqlParameter("@email", txtLoginID.Text);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            SqlParameter inputParameter2 = new SqlParameter("@password", txtLoginPassword.Text);
            inputParameter2.Direction = ParameterDirection.Input;
            inputParameter2.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter2);

            DataSet myDataSet = db.GetDataSetUsingCmdObj(objCommand);
            if (myDataSet.Tables[0].Rows.Count == 1)
            {
                Server.Transfer("HomePage.aspx");
            }
            else
            {
                lblErrorMsg2.Text = "Invalid Password!";
            }
            db.CloseConnection();
        } // end method

        protected void lnkBtnForgot_Click(object sender, EventArgs e)
        {
            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_GetUserID";

            SqlParameter inputParameter = new SqlParameter("@email", txtLoginID.Text);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            DataSet myDataSet = db.GetDataSetUsingCmdObj(objCommand);
            if (myDataSet.Tables[0].Rows.Count == 1)
            {
                pnlSecurity.Visible = true;
                lblSecurityQ1.Text = myDataSet.Tables[0].Rows[0].ItemArray[5].ToString();
                lblSecurityQ2.Text = myDataSet.Tables[0].Rows[0].ItemArray[6].ToString(); ;
                lblSecurityQ3.Text = myDataSet.Tables[0].Rows[0].ItemArray[7].ToString(); ;
            }
            else
            {
                lblErrorMsg1.Text = "User Name Not Found!";
            }
            db.CloseConnection();
        } // end method

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_GetUserID";

            SqlParameter inputParameter = new SqlParameter("@email", txtLoginID.Text);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            DataSet myDataSet = db.GetDataSetUsingCmdObj(objCommand);
            if (myDataSet.Tables[0].Rows.Count == 1)
            {
                string reply1 = txtSecurityA1.Text;
                string reply2 = txtSecurityA2.Text;
                string reply3 = txtSecurityA3.Text;

                string answer1 = myDataSet.Tables[0].Rows[0].ItemArray[8].ToString();
                string answer2 = myDataSet.Tables[0].Rows[0].ItemArray[9].ToString();
                string answer3 = myDataSet.Tables[0].Rows[0].ItemArray[10].ToString();

                if (reply1 == answer1 && reply2 == answer2 && reply3 == answer3)
                {
                    lblPassword.Text = "Your Password is: " + myDataSet.Tables[0].Rows[0].ItemArray[1].ToString();
                }
                else
                {
                    lblPassword.Text = "Wrong Answer!";
                }
            }
            else
            {
                lblPassword.Text = "User Not Found!";
            }
            db.CloseConnection();
        } // end method

    } // end class
} // end namespace