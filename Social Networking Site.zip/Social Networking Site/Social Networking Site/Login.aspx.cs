﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;

namespace Social_Networking_Site
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_Login";

            SqlParameter inputParameter = new SqlParameter("@email", txtLoginID.Text);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            SqlParameter inputParameter2 = new SqlParameter("@password", txtLoginPassword.Text);
            inputParameter2.Direction = ParameterDirection.Input;
            inputParameter2.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter2);

            DataSet myDataSet = db.GetDataSetUsingCmdObj(objCommand);
            if (myDataSet.Tables[0].Rows.Count == 1)
            {
                Server.Transfer("Home.aspx");
            }
            else
            {
                Response.Write("Invalid Email/Password");
            }
        }
    }
}