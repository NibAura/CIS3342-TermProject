﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Social_Networking_Site
{
    public partial class PhotoGallery : System.Web.UI.UserControl
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }


        public void setImage(String imageURL)
        {
            imgPic.ImageUrl = imageURL;
        }
        public void setDescription(String description)
        {
            lblDescription.Text = description;
        }
    }
}