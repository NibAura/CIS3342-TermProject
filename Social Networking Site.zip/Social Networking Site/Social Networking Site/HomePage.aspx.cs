﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Utilities;

namespace Social_Networking_Site
{
    public partial class HomePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //returns user to login page if there is no login cookie or if the login cookie does not say the user is signed in
            if (Request.Cookies["Social Network Login Cookie"] != null)
            {
                HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];
                if (!loginCookie.Values["Signed In?"].Equals("true"))
                {
                    Response.Redirect("LoginPage.aspx");
                }

                DBConnect db = new DBConnect();
                SqlCommand objCommand = new SqlCommand();
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.CommandText = "TP_GetUserInfo";

                SqlParameter inputParameter = new SqlParameter("@email", loginCookie.Values["Username"].ToString());
                inputParameter.Direction = ParameterDirection.Input;
                inputParameter.SqlDbType = SqlDbType.VarChar;
                objCommand.Parameters.Add(inputParameter);

                DataSet myDataSet = db.GetDataSetUsingCmdObj(objCommand);

                lblUsername.Text = "Welcome " + myDataSet.Tables[0].Rows[0].ItemArray[2].ToString();

                imgUser.ImageUrl = myDataSet.Tables[0].Rows[0].ItemArray[20].ToString();

                lblName.Text = myDataSet.Tables[0].Rows[0].ItemArray[2].ToString();

                lblAddress.Text = myDataSet.Tables[0].Rows[0].ItemArray[3].ToString();

                lblCity.Text = myDataSet.Tables[0].Rows[0].ItemArray[14].ToString();

                lblState.Text = myDataSet.Tables[0].Rows[0].ItemArray[15].ToString();

                lblPhoneNumber.Text = myDataSet.Tables[0].Rows[0].ItemArray[4].ToString();

                lblOrganization.Text = myDataSet.Tables[0].Rows[0].ItemArray[16].ToString();
            }
            else
            {
                Response.Redirect("LoginPage.aspx");
            }

            // load Friends List
            if (IsPostBack == false)    // if it's the first page load
            {
                HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];

                DBConnect db = new DBConnect();
                SqlCommand objCommand = new SqlCommand();
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.CommandText = "TP_FriendNames";

                SqlParameter inputParameter = new SqlParameter("@loginID", loginCookie.Values["Username"].ToString());
                inputParameter.Direction = ParameterDirection.Input;
                inputParameter.SqlDbType = SqlDbType.VarChar;
                objCommand.Parameters.Add(inputParameter);

                gvFriends.DataSource = db.GetDataSetUsingCmdObj(objCommand);
                gvFriends.DataBind();
                db.CloseConnection();

                db = new DBConnect();
                objCommand = new SqlCommand();
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.CommandText = "TP_GetLoginNewsFeed";

                inputParameter = new SqlParameter("@loginID", loginCookie.Values["Username"].ToString());
                inputParameter.Direction = ParameterDirection.Input;
                inputParameter.SqlDbType = SqlDbType.VarChar;
                objCommand.Parameters.Add(inputParameter);

                gvNewsFeed.DataSource = db.GetDataSetUsingCmdObj(objCommand);
                gvNewsFeed.DataBind();
                db.CloseConnection();
                LoadGallery();
            }
        } // end page load

        //sets the login cookie to expired signing the user out and redirects to login page
        protected void btnSignOut_Click(object sender, EventArgs e)
        {
            if (Request.Cookies["Social Network Login Cookie"] != null)
            {
                HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];
                loginCookie.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(loginCookie);
                Response.Redirect("LoginPage.aspx");
            }
        } // end method


        public void LoadGallery()
        {
            HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];

            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_GetPhotos";

            SqlParameter inputParameter = new SqlParameter("@loginID", loginCookie.Values["Username"].ToString());
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            DataSet ds = db.GetDataSetUsingCmdObj(objCommand);
            gvGallery.DataSource = ds;
            gvGallery.DataBind();
            PhotoGallery photoGallery;
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                photoGallery = (PhotoGallery)gvGallery.Rows[i].FindControl("ptgPhotoGallery");
                photoGallery.setImage(ds.Tables[0].Rows[i].ItemArray[1].ToString());
                photoGallery.setDescription(ds.Tables[0].Rows[i].ItemArray[2].ToString());
            }



        }

    } // end class
} // end namespace 