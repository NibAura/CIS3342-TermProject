﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace Social_Networking_Site
{
    public partial class HomePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //returns user to login page if there is no login cookie or if the login cookie does not say the user is signed in
            if (Request.Cookies["Social Network Login Cookie"] != null)
            {
                HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];
                if (!loginCookie.Values["Signed In?"].Equals("true"))
                {
                    Response.Redirect("LoginPage.aspx");
                }
            }
            else
            {
                Response.Redirect("LoginPage.aspx");
            }
        }

        //sets the login cookie to expired signing the user out and redirects to login page
        protected void btnSignOut_Click(object sender, EventArgs e)
        {
            if (Request.Cookies["Social Network Login Cookie"] != null)
            {
                HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];
                loginCookie.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(loginCookie);
                Response.Redirect("LoginPage.aspx");
            }
        }

        protected void btnSettings_Click(object sender, EventArgs e)
        {
            Response.Redirect("Settings.aspx");
        }
    }
}