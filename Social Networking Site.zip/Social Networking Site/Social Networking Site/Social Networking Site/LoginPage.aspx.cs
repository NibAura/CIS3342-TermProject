﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;
using Utilities;
using System.Text;
using System.Security.Cryptography;
using System.IO;

namespace Social_Networking_Site
{
    public partial class LoginPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                DecryptLogin();
            }
        } // end method

        private Byte[] key = { 250, 101, 18, 76, 45, 135, 207, 118, 4, 171, 3, 168, 202, 241, 37, 199 };

        private Byte[] vector = { 146, 64, 191, 111, 23, 3, 113, 119, 231, 121, 252, 112, 79, 32, 114, 156 };



        protected void btnLogin_Click(object sender, EventArgs e)
        {
            // clear the error message
            lblErrorMsg1.Text = "";
            lblErrorMsg2.Text = "";
            // call method to check user ID
            GetUserID();
            // call method to check login
            GetLogin();
        } // end method

        // method to retrieve the user ID (email) from database
        public void GetUserID()
        {
            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_GetUserID";

            SqlParameter inputParameter = new SqlParameter("@email", txtLoginID.Text);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            DataSet myDataSet = db.GetDataSetUsingCmdObj(objCommand);
            if (myDataSet.Tables[0].Rows.Count != 1)
            {
                lblErrorMsg1.Text = "Invalid User Name!";
            }

            db.CloseConnection();
        } // end method

        // method to retrieve the user ID (email) from database
        public void GetLogin()
        {
            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_Login";

            SqlParameter inputParameter = new SqlParameter("@email", txtLoginID.Text);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            SqlParameter inputParameter2 = new SqlParameter("@password", txtLoginPassword.Text);
            inputParameter2.Direction = ParameterDirection.Input;
            inputParameter2.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter2);

            DataSet myDataSet = db.GetDataSetUsingCmdObj(objCommand);
            if (myDataSet.Tables[0].Rows.Count == 1)
            {
                LoginCookie();
                Response.Redirect("HomePage.aspx");
            }
            else
            {
                lblErrorMsg2.Text = "Invalid Password!";
            }
            db.CloseConnection();
        } // end method

        protected void lnkBtnForgot_Click(object sender, EventArgs e)
        {
            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_GetUserID";

            SqlParameter inputParameter = new SqlParameter("@email", txtLoginID.Text);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            DataSet myDataSet = db.GetDataSetUsingCmdObj(objCommand);
            if (myDataSet.Tables[0].Rows.Count == 1)
            {
                pnlSecurity.Visible = true;
                lblSecurityQ1.Text = myDataSet.Tables[0].Rows[0].ItemArray[5].ToString();
                lblSecurityQ2.Text = myDataSet.Tables[0].Rows[0].ItemArray[6].ToString(); ;
                lblSecurityQ3.Text = myDataSet.Tables[0].Rows[0].ItemArray[7].ToString(); ;
            }
            else
            {
                lblErrorMsg1.Text = "User Name Not Found!";
            }
            db.CloseConnection();
        } // end method

        protected void btnSubmit_Click(object sender, EventArgs e)
        {
            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_GetUserID";

            SqlParameter inputParameter = new SqlParameter("@email", txtLoginID.Text);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            DataSet myDataSet = db.GetDataSetUsingCmdObj(objCommand);
            if (myDataSet.Tables[0].Rows.Count == 1)
            {
                string reply1 = txtSecurityA1.Text;
                string reply2 = txtSecurityA2.Text;
                string reply3 = txtSecurityA3.Text;

                string answer1 = myDataSet.Tables[0].Rows[0].ItemArray[8].ToString();
                string answer2 = myDataSet.Tables[0].Rows[0].ItemArray[9].ToString();
                string answer3 = myDataSet.Tables[0].Rows[0].ItemArray[10].ToString();

                if (reply1 == answer1 && reply2 == answer2 && reply3 == answer3)
                {
                    lblPassword.Text = "Your Password is: " + myDataSet.Tables[0].Rows[0].ItemArray[1].ToString();
                }
                else
                {
                    lblPassword.Text = "Wrong Answer!";
                }
            }
            else
            {
                lblPassword.Text = "User Not Found!";
            }
            db.CloseConnection();
        } // end method


        private void LoginCookie()
        {
            String user = txtLoginID.Text;
            String pass = txtLoginPassword.Text;
            String encryptedPass;

            UTF8Encoding encoder = new UTF8Encoding();      // used to convert bytes to characters, and back
            Byte[] textBytes;                               // stores the plain text data as bytes

            // Perform Encryption
            //-------------------
            // Convert a string to a byte array, which will be used in the encryption process.
            textBytes = encoder.GetBytes(pass);

            // Create an instances of the encryption algorithm (Rinjdael AES) for the encryption to perform,
            // a memory stream used to store the encrypted data temporarily, and
            // a crypto stream that performs the encryption algorithm.
            RijndaelManaged rmEncryption = new RijndaelManaged();
            MemoryStream myMemoryStream = new MemoryStream();
            CryptoStream myEncryptionStream = new CryptoStream(myMemoryStream, rmEncryption.CreateEncryptor(key, vector), CryptoStreamMode.Write);

            // Use the crypto stream to perform the encryption on the plain text byte array.
            myEncryptionStream.Write(textBytes, 0, textBytes.Length);
            myEncryptionStream.FlushFinalBlock();

            // Retrieve the encrypted data from the memory stream, and write it to a separate byte array.
            myMemoryStream.Position = 0;
            Byte[] encryptedBytes = new Byte[myMemoryStream.Length];
            myMemoryStream.Read(encryptedBytes, 0, encryptedBytes.Length);

            // Close all the streams.
            myEncryptionStream.Close();
            myMemoryStream.Close();

            //store encrypted password as a string
            encryptedPass = Convert.ToBase64String(encryptedBytes);

            //only stores user and pass to cookie if stay signed in is checked
            if (chkStaySignedIn.Checked)
            {
                //stores user and pass to cookie that expires in 2 days
                HttpCookie loginCookie = new HttpCookie("Social Network Login Cookie");
                loginCookie.Values["Username"] = user;
                loginCookie.Values["Password"] = encryptedPass;
                loginCookie.Values["Signed In?"] = "true";
                loginCookie.Expires = DateTime.Now.AddDays(2);
                Response.Cookies.Add(loginCookie);
            }
            //if stay signed in is unchecked but save user is checked saves only username to cookie
            //otherwise stay signed in takes priority
            else if (chkSaveUserOnly.Checked)
            {
                HttpCookie loginCookie = new HttpCookie("Social Network Login Cookie");
                loginCookie.Values["Username"] = user;
                loginCookie.Values["Signed In?"] = "true";
                loginCookie.Expires = DateTime.Now.AddDays(2);
                Response.Cookies.Add(loginCookie);
            }
            //no option is checked
            else
            {
                HttpCookie loginCookie = new HttpCookie("Social Network Login Cookie");
                loginCookie.Values["Signed In?"] = "true";
                loginCookie.Values["Username"] = user;
                loginCookie.Expires = DateTime.Now.AddDays(2);
                Response.Cookies.Add(loginCookie);
            }

        }

        private void DecryptLogin()
        {
            String user;
            String pass;

            if (Request.Cookies["Social Network Login Cookie"] != null)
            {
                HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];

                if (loginCookie.Values["Password"] != null)
                {
                    String encryptedPassword = loginCookie.Values["Password"];
                    user = loginCookie.Values["Username"];

                    Byte[] encryptedPasswordBytes = Convert.FromBase64String(encryptedPassword);
                    Byte[] textBytes;
                    UTF8Encoding encoder = new UTF8Encoding();

                    // Perform Decryption
                    //-------------------
                    // Create an instances of the decryption algorithm (Rinjdael AES) for the encryption to perform,
                    // a memory stream used to store the decrypted data temporarily, and
                    // a crypto stream that performs the decryption algorithm.
                    RijndaelManaged rmEncryption = new RijndaelManaged();
                    MemoryStream myMemoryStream = new MemoryStream();
                    CryptoStream myDecryptionStream = new CryptoStream(myMemoryStream, rmEncryption.CreateDecryptor(key, vector), CryptoStreamMode.Write);

                    // Use the crypto stream to perform the decryption on the encrypted data in the byte array.
                    myDecryptionStream.Write(encryptedPasswordBytes, 0, encryptedPasswordBytes.Length);
                    myDecryptionStream.FlushFinalBlock();

                    // Retrieve the decrypted data from the memory stream, and write it to a separate byte array.
                    myMemoryStream.Position = 0;
                    textBytes = new Byte[myMemoryStream.Length];
                    myMemoryStream.Read(textBytes, 0, textBytes.Length);

                    // Close all the streams.
                    myDecryptionStream.Close();
                    myMemoryStream.Close();

                    // Convert the bytes to a string and display it.
                    pass = encoder.GetString(textBytes);

                    txtLoginID.Text = user;
                    txtLoginPassword.Text = pass;
                    GetLogin();
                }
                else if (loginCookie.Values["Username"] != null)
                {
                    user = loginCookie.Values["Username"];
                    txtLoginID.Text = user;
                }
            }

        }

    } // end class
} // end namespace