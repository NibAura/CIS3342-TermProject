﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Data;
using System.Data.SqlClient;
using Utilities;

namespace Social_Networking_Site
{
    public partial class RegistrationPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        } // end method

        protected void btnSignUp_Click(object sender, EventArgs e)
        {
            // call method to check if account is available
            if (CheckUserID() == false)
            {
                // call method to add account to database
                AddAccount();
                lblErrorMsg.Text = "Account Successfully Created.";
            }
            else
            {
                lblErrorMsg.Text = "Invalid User/Email!";
            }
        } // end method

        // method to check if user name is taken
        public Boolean CheckUserID()
        {
            bool test = false;

            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_GetUserID";

            SqlParameter inputParameter = new SqlParameter("@email", txtEmail.Text);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            DataSet myDataSet = db.GetDataSetUsingCmdObj(objCommand);
            if (myDataSet.Tables[0].Rows.Count == 1)
            {
                test = true;
            }
            else
            {
                test = false;
            }

            db.CloseConnection();
            return test;
        } // end method


        // method to add user account to the database
        protected void AddAccount()
        {
            DBConnect objDB = new DBConnect();
            SqlCommand objCommand = new SqlCommand();

            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_AddAccount";
            // set textbox value to store procedures parameter
            objCommand.Parameters.AddWithValue("@LoginID", txtEmail.Text);
            objCommand.Parameters.AddWithValue("@Password", txtPassword.Text);
            objCommand.Parameters.AddWithValue("@Name", txtName.Text);
            objCommand.Parameters.AddWithValue("@Address", txtAddress.Text);
            objCommand.Parameters.AddWithValue("@PhoneNumber", txtPhone.Text);
            objCommand.Parameters.AddWithValue("@SecurityQuestion1", ddlSecurityQ1.Text);
            objCommand.Parameters.AddWithValue("@SecurityQuestion2", ddlSecurityQ2.Text);
            objCommand.Parameters.AddWithValue("@SecurityQuestion3", ddlSecurityQ3.Text);
            objCommand.Parameters.AddWithValue("@Answer1", txtSecurityA1.Text);
            objCommand.Parameters.AddWithValue("@Answer2", txtSecurityA2.Text);
            objCommand.Parameters.AddWithValue("@Answer3", txtSecurityA3.Text);
            objCommand.Parameters.AddWithValue("@City", txtCity.Text);
            objCommand.Parameters.AddWithValue("@theState", txtState.Text);
            objCommand.Parameters.AddWithValue("@organization", txtOrganization.Text);
            // set sql object
            objDB.DoUpdateUsingCmdObj(objCommand);
            objDB.CloseConnection();
        } // end method

    } // end class
} // end namespace