﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using System.Web.Script.Serialization;  // needed for JSON serializers
using System.IO;                        // needed for Stream and Stream Reader
using System.Net;                       // needed for the Web Request
//using Core2WebAPI;                      // needed for the Team class
using Utilities;
using System.Data;
using System.Data.SqlClient;

namespace Social_Networking_Site
{
    public partial class FriendsPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        } // end page load

        //sets the login cookie to expired signing the user out and redirects to login page
        protected void btnSignOut_Click(object sender, EventArgs e)
        {
            if (Request.Cookies["Social Network Login Cookie"] != null)
            {
                HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];
                loginCookie.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(loginCookie);
                Response.Redirect("LoginPage.aspx");
            }
        } // end method

        protected void ddlSearchType_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (ddlSearchType.SelectedIndex == 0)
            {
                pnlName.Visible = true;
                pnlLoc.Visible = false;
                pnlOrg.Visible = false;
            }
            else if (ddlSearchType.SelectedIndex == 1)
            {
                pnlName.Visible = false;
                pnlLoc.Visible = true;
                pnlOrg.Visible = false;
            }
            else
            {
                pnlName.Visible = false;
                pnlLoc.Visible = false;
                pnlOrg.Visible = true;
            }
        } // end event handler

        protected void btnSearch_Click(object sender, EventArgs e)
        {
            if (ddlSearchType.SelectedIndex == 0)
            {
                // Create an HTTP Web Request and get the HTTP Web Response from the server.
                WebRequest request = WebRequest.Create("http://localhost:51795/api/SocialNetworkService/FindUsersByName/" + txtSearchName.Text);

                WebResponse response = request.GetResponse();

                // Read the data from the Web Response, which requires working with streams.
                Stream theDataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(theDataStream);
                String data = reader.ReadToEnd();
                reader.Close();
                response.Close();

                // Deserialize a JSON string that contains an array of JSON objects into an Array of Team objects.
                JavaScriptSerializer js = new JavaScriptSerializer();
                UserAccount[] users = js.Deserialize<UserAccount[]>(data);
                gvSearch.DataSource = users;
                gvSearch.DataBind();
            }
            else if (ddlSearchType.SelectedIndex == 1)
            {
                // Create an HTTP Web Request and get the HTTP Web Response from the server.
                WebRequest request = WebRequest.Create("http://localhost:51795/api/SocialNetworkService/FindUsersByLocation/" + txtSearchCity.Text + "/" + txtSearchState.Text);

                WebResponse response = request.GetResponse();

                // Read the data from the Web Response, which requires working with streams.
                Stream theDataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(theDataStream);
                String data = reader.ReadToEnd();
                reader.Close();
                response.Close();

                // Deserialize a JSON string that contains an array of JSON objects into an Array of Team objects.
                JavaScriptSerializer js = new JavaScriptSerializer();
                UserAccount[] users = js.Deserialize<UserAccount[]>(data);
                gvSearch.DataSource = users;
                gvSearch.DataBind();
            }
            else
            {
                // Create an HTTP Web Request and get the HTTP Web Response from the server.
                WebRequest request = WebRequest.Create("http://localhost:51795/api/SocialNetworkService/FindUsersByOrganization/" + txtSearchOrg.Text);

                WebResponse response = request.GetResponse();

                // Read the data from the Web Response, which requires working with streams.
                Stream theDataStream = response.GetResponseStream();
                StreamReader reader = new StreamReader(theDataStream);
                String data = reader.ReadToEnd();
                reader.Close();
                response.Close();

                // Deserialize a JSON string that contains an array of JSON objects into an Array of Team objects.
                JavaScriptSerializer js = new JavaScriptSerializer();
                UserAccount[] users = js.Deserialize<UserAccount[]>(data);
                gvSearch.DataSource = users;
                gvSearch.DataBind();
            }
        }
    } // end class
} //end namespace