﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Utilities;
using System.Data;
using System.Data.SqlClient;

namespace Social_Networking_Site
{
    public partial class ProfilePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //returns user to login page if there is no login cookie or if the login cookie does not say the user is signed in
            if (Request.Cookies["Social Network Login Cookie"] != null)
            {
                HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];
                if (!loginCookie.Values["Signed In?"].Equals("true"))
                {
                    Response.Redirect("LoginPage.aspx");
                }

                DBConnect db = new DBConnect();
                SqlCommand objCommand = new SqlCommand();
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.CommandText = "TP_GetUserID";

                SqlParameter inputParameter = new SqlParameter("@email", loginCookie.Values["Username"].ToString());
                inputParameter.Direction = ParameterDirection.Input;
                inputParameter.SqlDbType = SqlDbType.VarChar;
                objCommand.Parameters.Add(inputParameter);

                DataSet myDataSet = db.GetDataSetUsingCmdObj(objCommand);

                lblUsername.Text = myDataSet.Tables[0].Rows[0].ItemArray[2].ToString() + "'s Profile";

                imgUser.ImageUrl = myDataSet.Tables[0].Rows[0].ItemArray[17].ToString();

                lblName.Text = myDataSet.Tables[0].Rows[0].ItemArray[2].ToString();

                lblAddress.Text = myDataSet.Tables[0].Rows[0].ItemArray[3].ToString();

                lblCity.Text = myDataSet.Tables[0].Rows[0].ItemArray[14].ToString();

                lblState.Text = myDataSet.Tables[0].Rows[0].ItemArray[15].ToString();

                lblPhoneNumber.Text = myDataSet.Tables[0].Rows[0].ItemArray[4].ToString();

                lblOrganization.Text = myDataSet.Tables[0].Rows[0].ItemArray[16].ToString();

            }
            else
            {
                Response.Redirect("LoginPage.aspx");
            }
        } // end page load

        //sets the login cookie to expired signing the user out and redirects to login page
        protected void btnSignOut_Click(object sender, EventArgs e)
        {
            if (Request.Cookies["Social Network Login Cookie"] != null)
            {
                HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];
                loginCookie.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(loginCookie);
                Response.Redirect("LoginPage.aspx");
            }
        } // end method

    } // end class
} // end namespace