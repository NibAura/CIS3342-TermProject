﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Utilities;
using System.Data;
using System.Data.SqlClient;
using System.IO;

namespace Social_Networking_Site
{
    public partial class ProfilePage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //returns user to login page if there is no login cookie or if the login cookie does not say the user is signed in
            if (Request.Cookies["Social Network Login Cookie"] != null)
            {
                HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];
                if (!loginCookie.Values["Signed In?"].Equals("true"))
                {
                    Response.Redirect("LoginPage.aspx");
                }

                DBConnect db = new DBConnect();
                SqlCommand objCommand = new SqlCommand();
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.CommandText = "TP_GetUserInfo";

                SqlParameter inputParameter = new SqlParameter("@email", loginCookie.Values["Username"].ToString());
                inputParameter.Direction = ParameterDirection.Input;
                inputParameter.SqlDbType = SqlDbType.VarChar;
                objCommand.Parameters.Add(inputParameter);

                DataSet myDataSet = db.GetDataSetUsingCmdObj(objCommand);

                lblUsername.Text = myDataSet.Tables[0].Rows[0].ItemArray[2].ToString() + "'s Profile";

                imgUser.ImageUrl = myDataSet.Tables[0].Rows[0].ItemArray[20].ToString();

                lblName.Text = myDataSet.Tables[0].Rows[0].ItemArray[2].ToString();

                lblAddress.Text = myDataSet.Tables[0].Rows[0].ItemArray[3].ToString();

                lblCity.Text = myDataSet.Tables[0].Rows[0].ItemArray[14].ToString();

                lblState.Text = myDataSet.Tables[0].Rows[0].ItemArray[15].ToString();

                lblPhoneNumber.Text = myDataSet.Tables[0].Rows[0].ItemArray[4].ToString();

                lblOrganization.Text = myDataSet.Tables[0].Rows[0].ItemArray[16].ToString();

            }
            else
            {
                Response.Redirect("LoginPage.aspx");
            }

            // load Friends List
            if (IsPostBack == false)    // if it's the first page load
            {
                getWall();
                LoadGallery();

            }

        } // end page load

        private void getWall()
        {
            HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];

            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_FriendNames";

            SqlParameter inputParameter = new SqlParameter("@loginID", loginCookie.Values["Username"].ToString());
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            gvFriends.DataSource = db.GetDataSetUsingCmdObj(objCommand);
            gvFriends.DataBind();
            db.CloseConnection();

            db = new DBConnect();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_GetWall";

            inputParameter = new SqlParameter("@loginID", loginCookie.Values["Username"].ToString());
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            gvWall.DataSource = db.GetDataSetUsingCmdObj(objCommand);
            gvWall.DataBind();
            db.CloseConnection();

        }

        //sets the login cookie to expired signing the user out and redirects to login page
        protected void btnSignOut_Click(object sender, EventArgs e)
        {
            if (Request.Cookies["Social Network Login Cookie"] != null)
            {
                HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];
                loginCookie.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(loginCookie);
                Response.Redirect("LoginPage.aspx");
            }
        } // end method

        protected void btnPost_Click(object sender, EventArgs e)
        {
            HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];

            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_PostToWall";

            SqlParameter inputParameter = new SqlParameter("@loginID", loginCookie.Values["Username"].ToString());
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            SqlParameter inputParameter2 = new SqlParameter("@receiverID", loginCookie.Values["Username"].ToString());
            inputParameter2.Direction = ParameterDirection.Input;
            inputParameter2.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter2);

            SqlParameter inputParameter3 = new SqlParameter("@message", txtMessage.InnerText);
            inputParameter3.Direction = ParameterDirection.Input;
            inputParameter3.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter3);
            db.DoUpdateUsingCmdObj(objCommand);

            getWall();
        }

        public void LoadGallery()
        {
            HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];

            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_GetPhotos";

            SqlParameter inputParameter = new SqlParameter("@loginID", loginCookie.Values["Username"].ToString());
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            DataSet ds = db.GetDataSetUsingCmdObj(objCommand);
            gvGallery.DataSource=ds;
            gvGallery.DataBind();
            PhotoGallery photoGallery;
            for (int i = 0; i < ds.Tables[0].Rows.Count; i++)
            {
                photoGallery = (PhotoGallery)gvGallery.Rows[i].FindControl("ptgPhotoGallery");
                photoGallery.setImage(ds.Tables[0].Rows[i].ItemArray[1].ToString());
                photoGallery.setDescription(ds.Tables[0].Rows[i].ItemArray[2].ToString());
            }



        }

        protected void btnUpload_Click(object sender, EventArgs e)
        {
            HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];

            DBConnect db = new DBConnect();

            SqlCommand objCommand = new SqlCommand();
            int imageSize;
            string fileExtension, imageType, imageName, imageTitle;
            try

            {

                // Use the FileUpload control to get the uploaded data

                if (FileUploader.HasFile)

                {

                    imageSize = FileUploader.PostedFile.ContentLength;

                    byte[] imageData = new byte[imageSize];
                    FileUploader.PostedFile.InputStream.Read(imageData, 0, imageSize);

                    imageName = FileUploader.PostedFile.FileName;

                    imageType = FileUploader.PostedFile.ContentType;

                    if (txtDescription.Text != "")

                        imageTitle = txtDescription.Text;

                    fileExtension = imageName.Substring(imageName.LastIndexOf("."));

                    fileExtension = fileExtension.ToLower();
                    if (fileExtension == ".jpg" || fileExtension == ".jpeg" || fileExtension == ".bmp" || fileExtension == ".gif")

                    {


                        objCommand.CommandText = "TP_UploadPhoto";

                        objCommand.CommandType = CommandType.StoredProcedure;                    

                        objCommand.Parameters.AddWithValue("@PhotoURL", FileUploader.PostedFile.FileName);
                        objCommand.Parameters.AddWithValue("@description", txtDescription.Text);
                        objCommand.Parameters.AddWithValue("@loginID", loginCookie.Values["Username"].ToString());
                        db.DoUpdateUsingCmdObj(objCommand);
                        FileUploader.PostedFile.SaveAs(Server.MapPath("~/Images/"+ FileUploader.PostedFile.FileName));
                        //lblPath.Text = Server.MapPath("~/Images/" + FileUploader.PostedFile.FileName);
                            
                    }
                    else
                    {
                        //Only jpg, bmp, and gif file formats supported
                        Response.Write("Only jpg, bmp, and gif file formats supported");
                    }
                }
            }
            catch (Exception ex)
            {
                //error
            }
        }
    } // end class
} // end namespace