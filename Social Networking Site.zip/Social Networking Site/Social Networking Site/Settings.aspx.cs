﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Utilities;

namespace Social_Networking_Site
{
    public partial class Settings : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //returns user to login page if there is no login cookie or if the login cookie does not say the user is signed in
            if (Request.Cookies["Social Network Login Cookie"] != null)
            {
                HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];
                if (!loginCookie.Values["Signed In?"].Equals("true"))
                {
                    Response.Redirect("LoginPage.aspx");
                }

                DBConnect db = new DBConnect();
                SqlCommand objCommand = new SqlCommand();
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.CommandText = "TP_GetUserID";

                SqlParameter inputParameter = new SqlParameter("@email", loginCookie.Values["Username"].ToString());
                inputParameter.Direction = ParameterDirection.Input;
                inputParameter.SqlDbType = SqlDbType.VarChar;
                objCommand.Parameters.Add(inputParameter);

                DataSet myDataSet = db.GetDataSetUsingCmdObj(objCommand);
            
                txtEmail.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[0].ToString());

                txtPassword.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[1].ToString());

                txtName.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[2].ToString());

                txtAddress.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[3].ToString());

                txtCity.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[14].ToString());

                txtState.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[15].ToString());

                txtPhone.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[4].ToString());

                txtOrganization.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[16].ToString());

                ddlSecurityQ1.SelectedValue = myDataSet.Tables[0].Rows[0].ItemArray[5].ToString();

                txtSecurityA1.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[8].ToString());

                ddlSecurityQ2.SelectedValue = myDataSet.Tables[0].Rows[0].ItemArray[6].ToString();

                txtSecurityA2.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[9].ToString());

                ddlSecurityQ3.SelectedValue = myDataSet.Tables[0].Rows[0].ItemArray[7].ToString();

                txtSecurityA3.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[10].ToString());

                ddlPhotoPrivacy.SelectedValue = myDataSet.Tables[0].Rows[0].ItemArray[11].ToString();

                ddlProfilePrivacy.SelectedValue = myDataSet.Tables[0].Rows[0].ItemArray[12].ToString();

                ddlContactPrivacy.SelectedValue = myDataSet.Tables[0].Rows[0].ItemArray[13].ToString();
            }
            else
            {
                Response.Redirect("LoginPage.aspx");
            }
        } // end page load

        protected void btnSaveChanges_Click(object sender, EventArgs e)
        {
            int photo = ddlPhotoPrivacy.SelectedIndex+1;
            int profile = ddlProfilePrivacy.SelectedIndex + 1;
            int contact = ddlContactPrivacy.SelectedIndex + 1;
            String user;
            HttpCookie cookie = Request.Cookies["Social Network Login Cookie"];
            user = cookie.Values["User"];

            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();

            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_UpdatePrivacySettings";
            // set textbox value to store procedures parameter

            SqlParameter inputParameter = new SqlParameter("@id", user);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            SqlParameter inputParameter2 = new SqlParameter("@photo", photo);
            inputParameter2.Direction = ParameterDirection.Input;
            inputParameter2.SqlDbType = SqlDbType.Int;
            objCommand.Parameters.Add(inputParameter2);

            SqlParameter inputParameter3 = new SqlParameter("@profile", profile);
            inputParameter3.Direction = ParameterDirection.Input;
            inputParameter3.SqlDbType = SqlDbType.Int;
            objCommand.Parameters.Add(inputParameter3);

            SqlParameter inputParameter4 = new SqlParameter("@contact", contact);
            inputParameter4.Direction = ParameterDirection.Input;
            inputParameter4.SqlDbType = SqlDbType.Int;
            objCommand.Parameters.Add(inputParameter4);

            db.DoUpdateUsingCmdObj(objCommand);
            db.CloseConnection();
            Response.Write("Changes saved. Click the back button to return to the home page.");
        } // end page load

        //sets the login cookie to expired signing the user out and redirects to login page
        protected void btnSignOut_Click(object sender, EventArgs e)
        {
            if (Request.Cookies["Social Network Login Cookie"] != null)
            {
                HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];
                loginCookie.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(loginCookie);
                Response.Redirect("LoginPage.aspx");
            }
        } // end method

    } // end class
} // end namespace