﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using Utilities;

namespace Social_Networking_Site
{
    public partial class Settings : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                //returns user to login page if there is no login cookie or if the login cookie does not say the user is signed in
                if (Request.Cookies["Social Network Login Cookie"] != null)
                {
                    HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];
                    if (!loginCookie.Values["Signed In?"].Equals("true"))
                    {
                        Response.Redirect("LoginPage.aspx");
                    }

                    DBConnect db = new DBConnect();
                    SqlCommand objCommand = new SqlCommand();
                    objCommand.CommandType = CommandType.StoredProcedure;
                    objCommand.CommandText = "TP_GetUserID";

                    SqlParameter inputParameter = new SqlParameter("@email", loginCookie.Values["Username"].ToString());
                    inputParameter.Direction = ParameterDirection.Input;
                    inputParameter.SqlDbType = SqlDbType.VarChar;
                    objCommand.Parameters.Add(inputParameter);

                    DataSet myDataSet = db.GetDataSetUsingCmdObj(objCommand);

                    db.CloseConnection();

                    lblUser.Text = myDataSet.Tables[0].Rows[0].ItemArray[0].ToString();

                    txtPassword.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[1].ToString());
                    txtPassword.Text = myDataSet.Tables[0].Rows[0].ItemArray[1].ToString();

                    txtName.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[2].ToString());
                    txtName.Text = myDataSet.Tables[0].Rows[0].ItemArray[2].ToString();

                    txtAddress.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[3].ToString());
                    txtAddress.Text = myDataSet.Tables[0].Rows[0].ItemArray[3].ToString();

                    txtCity.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[14].ToString());
                    txtCity.Text = myDataSet.Tables[0].Rows[0].ItemArray[14].ToString();

                    txtState.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[15].ToString());
                    txtState.Text = myDataSet.Tables[0].Rows[0].ItemArray[15].ToString();

                    txtPhone.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[4].ToString());
                    txtPhone.Text = myDataSet.Tables[0].Rows[0].ItemArray[4].ToString();

                    txtOrganization.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[16].ToString());
                    txtOrganization.Text = myDataSet.Tables[0].Rows[0].ItemArray[16].ToString();

                    ddlSecurityQ1.SelectedValue = myDataSet.Tables[0].Rows[0].ItemArray[5].ToString();

                    txtSecurityA1.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[8].ToString());
                    txtSecurityA1.Text = myDataSet.Tables[0].Rows[0].ItemArray[8].ToString();

                    ddlSecurityQ2.SelectedValue = myDataSet.Tables[0].Rows[0].ItemArray[6].ToString();

                    txtSecurityA2.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[9].ToString());
                    txtSecurityA2.Text = myDataSet.Tables[0].Rows[0].ItemArray[9].ToString();

                    ddlSecurityQ3.SelectedValue = myDataSet.Tables[0].Rows[0].ItemArray[7].ToString();

                    txtSecurityA3.Attributes.Add("placeholder", myDataSet.Tables[0].Rows[0].ItemArray[10].ToString());
                    txtSecurityA3.Text = myDataSet.Tables[0].Rows[0].ItemArray[10].ToString();

                    ddlPhotoPrivacy.SelectedIndex = (int)myDataSet.Tables[0].Rows[0].ItemArray[11] - 1;

                    ddlProfilePrivacy.SelectedIndex = (int)myDataSet.Tables[0].Rows[0].ItemArray[12] - 1;

                    ddlContactPrivacy.SelectedIndex = (int)myDataSet.Tables[0].Rows[0].ItemArray[13] - 1;
                }
                else
                {
                    Response.Redirect("LoginPage.aspx");
                }
            }
        } // end page load

        protected void btnSaveChanges_Click(object sender, EventArgs e)
        {
            String user;
            int photo = ddlPhotoPrivacy.SelectedIndex + 1;
            int profile = ddlProfilePrivacy.SelectedIndex + 1;
            int contact = ddlContactPrivacy.SelectedIndex + 1;

            HttpCookie cookie = Request.Cookies["Social Network Login Cookie"];
            user = cookie.Values["Username"];

            DBConnect objDB = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_UpdatePrivacySettings2";

            // set textbox value to store procedures parameter
            objCommand.Parameters.AddWithValue("@LoginID", user);
            objCommand.Parameters.AddWithValue("@Password", txtPassword.Text);
            objCommand.Parameters.AddWithValue("@Name", txtName.Text);
            objCommand.Parameters.AddWithValue("@Address", txtAddress.Text);
            objCommand.Parameters.AddWithValue("@PhoneNumber", txtPhone.Text);
            objCommand.Parameters.AddWithValue("@SecurityQuestion1", ddlSecurityQ1.SelectedValue);
            objCommand.Parameters.AddWithValue("@SecurityQuestion2", ddlSecurityQ2.SelectedValue);
            objCommand.Parameters.AddWithValue("@SecurityQuestion3", ddlSecurityQ3.SelectedValue);
            objCommand.Parameters.AddWithValue("@Answer1", txtSecurityA1.Text);
            objCommand.Parameters.AddWithValue("@Answer2", txtSecurityA2.Text);
            objCommand.Parameters.AddWithValue("@Answer3", txtSecurityA3.Text);
            objCommand.Parameters.AddWithValue("@City", txtCity.Text);
            objCommand.Parameters.AddWithValue("@State", txtState.Text);
            objCommand.Parameters.AddWithValue("@Organization", txtOrganization.Text);
            objCommand.Parameters.AddWithValue("@PhotoPrivacyLevel", photo);
            objCommand.Parameters.AddWithValue("@ProfilePrivacyLevel", profile);
            objCommand.Parameters.AddWithValue("@ContactPrivacyLevel", contact);
            objCommand.Parameters.AddWithValue("@ThemeSetting", ddlTheme.SelectedValue);
            // set sql object
            objDB.DoUpdateUsingCmdObj(objCommand);
            objDB.CloseConnection();

            lblSysMsg.Text = "Update Success!";
        } // end page load

        //sets the login cookie to expired signing the user out and redirects to login page
        protected void btnSignOut_Click(object sender, EventArgs e)
        {
            if (Request.Cookies["Social Network Login Cookie"] != null)
            {
                HttpCookie loginCookie = Request.Cookies["Social Network Login Cookie"];
                loginCookie.Expires = DateTime.Now.AddDays(-1);
                Response.Cookies.Add(loginCookie);
                Response.Redirect("LoginPage.aspx");
            }
        } // end method

    } // end class
} // end namespace