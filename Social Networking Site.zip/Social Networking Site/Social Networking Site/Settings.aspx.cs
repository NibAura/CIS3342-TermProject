﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Utilities;

namespace Social_Networking_Site
{
    public partial class Settings : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnBack_Click(object sender, EventArgs e)
        {
            Response.Redirect("HomePage.aspx");
        }

        protected void btnSaveChanges_Click(object sender, EventArgs e)
        {
            int photo = ddlPhotoPrivacy.SelectedIndex+1;
            int profile = ddlProfilePrivacy.SelectedIndex + 1;
            int contact = ddlContactPrivacy.SelectedIndex + 1;
            String user;
            HttpCookie cookie = Request.Cookies["Social Network Login Cookie"];
            user = cookie.Values["User"];

            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();

            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_UpdatePrivacySettings";
            // set textbox value to store procedures parameter

            SqlParameter inputParameter = new SqlParameter("@id", user);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            SqlParameter inputParameter2 = new SqlParameter("@photo", photo);
            inputParameter2.Direction = ParameterDirection.Input;
            inputParameter2.SqlDbType = SqlDbType.Int;
            objCommand.Parameters.Add(inputParameter2);

            SqlParameter inputParameter3 = new SqlParameter("@profile", profile);
            inputParameter3.Direction = ParameterDirection.Input;
            inputParameter3.SqlDbType = SqlDbType.Int;
            objCommand.Parameters.Add(inputParameter3);

            SqlParameter inputParameter4 = new SqlParameter("@contact", contact);
            inputParameter4.Direction = ParameterDirection.Input;
            inputParameter4.SqlDbType = SqlDbType.Int;
            objCommand.Parameters.Add(inputParameter4);

            db.DoUpdateUsingCmdObj(objCommand);
            db.CloseConnection();
            Response.Write("Changes saved. Click the back button to return to the home page.");
        }
    }
}