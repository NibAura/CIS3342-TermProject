﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilities
{
    public class NewsFeed
    {
        private int newsFeedID;
        private string loginID;
        private string posterID;
        private string message;

        public int NewsFeedID { get; set; }

        public string LoginID { get; set; }

        public string PosterID { get; set; }

        public string Message { get; set; }

    } // end class
} // end namespace
