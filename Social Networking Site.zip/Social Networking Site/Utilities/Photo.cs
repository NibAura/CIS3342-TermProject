﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilities
{
    public class Photo
    {
        private int photoID;
        private string photoURL;
        private string photoDescription;
        private string loginID;
        private string album;

        public int PhotoID { get; set; }

        public string PhotoURL { get; set; }

        public string PhotoDescription { get; set; }

        public string LoginID { get; set; }

        public string Album { get; set; }

    } // end class
} // end namespace
