﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilities
{
    public class Friend
    {
        private int friendID;
        private string loginID;
        private string friendLoginID;
        private int subscribed;
        private int verifyToken;

        public int FriendID { get; set; }

        public string LoginID { get; set; }

        public string FriendLoginID { get; set; }

        public int Subscribed { get; set; }

        public int VerifyToken { get; set; }

    } // end class
} // end namespace

