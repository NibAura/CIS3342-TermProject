﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Utilities
{
    public class UserAccount
    {
        private string loginID;
        private string password;
        private string name;
        private string address;
        private string city;
        private string state;
        private string phoneNumber;
        private string organizaion;
        private string profilePhotoURL;

        public string LoginID {get; set;}

        public string Password { get; set; }

        public string Name { get; set; }

        public string Address { get; set; }

        public string City { get; set; }

        public string State { get; set; }

        public string PhoneNumber { get; set; }

        public string Organization { get; set; }

        public string ProfilePhotoURL { get; set; }

    } // end class
} // end namespace
