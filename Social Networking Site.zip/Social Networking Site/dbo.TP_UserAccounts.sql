﻿CREATE TABLE [dbo].[TP_UserAccounts]
(
	[LoginID] VARCHAR(50) NOT NULL PRIMARY KEY, 
    [Name] VARCHAR(50) NOT NULL, 
    [Address] VARCHAR(50) NOT NULL, 
    [PhoneNumber] VARCHAR(50) NOT NULL, 
    [Password] VARCHAR(50) NOT NULL, 
    [SecurityQuestion1] VARCHAR(50) NOT NULL, 
    [SecurityQuestion2] VARCHAR(50) NOT NULL, 
    [SecurityQuestion3] VARCHAR(50) NOT NULL, 
    [Answer1] VARCHAR(50) NOT NULL, 
    [Answer2] VARCHAR(50) NOT NULL, 
    [Answer3] VARCHAR(50) NOT NULL
)
