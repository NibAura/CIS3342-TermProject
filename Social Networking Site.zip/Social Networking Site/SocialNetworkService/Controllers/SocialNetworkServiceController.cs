﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using System.Data;              // import needed for DataSet and other data classes
using System.Data.SqlClient;    // import needed for ADO.NET classes
using Utilities;                // import needed for DBConnect class
using Newtonsoft.Json.Serialization;
using System.Collections;

namespace SocialNetworkService.Controllers
{
    [Produces("application/json")]
    //[Route("api/SocialNetworkService")]
    [Route("api/[controller]/")]
    public class SocialNetworkServiceController : Controller
    {
        // public services
        // GET: api/FindByName/name
        [HttpGet("FindUsersByName/{name}")]
        public List<UserAccount> FindUsersByName(string name)
        {
            //DBConnect objDB = new DBConnect();
            //DataSet ds = objDB.GetDataSet("SELECT * FROM TP_UserAccounts WHERE Name ='" + name + "';");

            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_FindByName";
            SqlParameter inputParameter = new SqlParameter("@name", name);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);
            DataSet ds = db.GetDataSetUsingCmdObj(objCommand);

            List<UserAccount> profiles = new List<UserAccount>();
            UserAccount profile;

            foreach (DataRow record in ds.Tables[0].Rows)
            {
                profile = new UserAccount();
                profile.Name = record["Name"].ToString();
                profile.City = record["City"].ToString();
                profile.State = record["State"].ToString();
                profile.Organization = record["Organization"].ToString();
                profile.ProfilePhotoURL = record["ProfilePhotoURL"].ToString();
                profiles.Add(profile);
            }

            return profiles;
        } // end method

        // GET: api/FindUsersByLocation/city/state
        [HttpGet("FindUsersByLocation/{city}/{state}/")]
        public List<UserAccount> FindUsersByLocation(string city, string state)
        {
            //DBConnect objDB = new DBConnect();
            //DataSet ds = objDB.GetDataSet("SELECT * FROM TP_UserAccounts WHERE City = '" + city + "' AND State = '" + state + "';");

            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_FindByLocation";
            SqlParameter inputParameter = new SqlParameter("@city", city);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            SqlParameter inputParameter2 = new SqlParameter("@state", state);
            inputParameter2.Direction = ParameterDirection.Input;
            inputParameter2.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter2);

            DataSet ds = db.GetDataSetUsingCmdObj(objCommand);

            List<UserAccount> profiles = new List<UserAccount>();
            UserAccount profile;

            foreach (DataRow record in ds.Tables[0].Rows)
            {
                profile = new UserAccount();
                profile.Name = record["Name"].ToString();
                profile.City = record["City"].ToString();
                profile.State = record["State"].ToString();
                profile.Organization = record["Organization"].ToString();
                profile.ProfilePhotoURL = record["ProfilePhotoURL"].ToString();
                profiles.Add(profile);
            }

            return profiles;
        } // end method

        // GET: api/FindUsersByOrganization/organization
        [HttpGet("FindUsersByOrganization/{organization}")]
        public List<UserAccount> FindUsersByOrganization(string organization)
        {
            //DBConnect objDB = new DBConnect();
            //DataSet ds = objDB.GetDataSet("SELECT * FROM TP_UserAccounts WHERE Organization ='" + organization + "';");

            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_FindByOrganization";
            SqlParameter inputParameter = new SqlParameter("@organization", organization);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            DataSet ds = db.GetDataSetUsingCmdObj(objCommand);

            List<UserAccount> profiles = new List<UserAccount>();
            UserAccount profile;

            foreach (DataRow record in ds.Tables[0].Rows)
            {
                profile = new UserAccount();
                profile.Name = record["Name"].ToString();
                profile.City = record["City"].ToString();
                profile.State = record["State"].ToString();
                profile.Organization = record["Organization"].ToString();
                profile.ProfilePhotoURL = record["ProfilePhotoURL"].ToString();
                profiles.Add(profile);
            }

            return profiles;
        } // end method
        // end public services

        // private services
        // GET: api/GetFriend/requestingUsername/requestedUsername/verificationToken
        [HttpGet("GetFriends/{requestingUsername}/{requestedUsername}/{verificationToken}/")]
        public List<UserAccount> GetFriends(string requestingUsername, string requestedUsername, string verificationToken)
        {
            //DBConnect objDB = new DBConnect();
            //DataSet ds = objDB.GetDataSet("SELECT * FROM TP_Friends INNER JOIN TP_UserAccounts ON TP_Friends.LoginID = '" + city + "' AND State = '" + state + "';");

            //checks if friends with searched person
            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_CheckFriends";
            SqlParameter inputParameter = new SqlParameter("@loginID", requestingUsername);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            SqlParameter inputParameter2 = new SqlParameter("@friendLogin", requestedUsername);
            inputParameter2.Direction = ParameterDirection.Input;
            inputParameter2.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter2);

            DataSet ds = db.GetDataSetUsingCmdObj(objCommand);

            //record was returned. person is a friend
            //finds list of persons friends and returns it
            if (ds.Tables[0].Rows.Count != 0)
            {
                db = new DBConnect();
                objCommand = new SqlCommand();
                objCommand.CommandType = CommandType.StoredProcedure;
                objCommand.CommandText = "TP_GetFriends";
                inputParameter = new SqlParameter("@username", requestedUsername);
                inputParameter.Direction = ParameterDirection.Input;
                inputParameter.SqlDbType = SqlDbType.VarChar;
                objCommand.Parameters.Add(inputParameter);
                ds = db.GetDataSetUsingCmdObj(objCommand);

                List<UserAccount> profiles = new List<UserAccount>();
                UserAccount profile;

                foreach (DataRow record in ds.Tables[0].Rows)
                {
                    profile = new UserAccount();
                    profile.Name = record["Name"].ToString();
                    profile.ProfilePhotoURL = record["ProfilePhotoURL"].ToString();
                    profiles.Add(profile);
                }
                return profiles;
            }
            else
            {
                //not friends with person being searched
                //returns empty list
                List<UserAccount> profiles = new List<UserAccount>();
                return profiles;
            }


            
            

           
        } // end method

    // GET: api/FindByLocation/city/state
    [HttpGet("GetArrFriends/{requestingUsername}/{requestedUsername}/{verificationToken}/")]
    public ArrayList GetArrFriends(string RequestingUsername, string RequestedUsername, string VerificationToken)
    {
        //checks if friends with searched person
        DBConnect db = new DBConnect();
        SqlCommand objCommand = new SqlCommand();
        objCommand.CommandType = CommandType.StoredProcedure;
        objCommand.CommandText = "TP_CheckFriends";
        SqlParameter inputParameter = new SqlParameter("@loginID", RequestingUsername);
        inputParameter.Direction = ParameterDirection.Input;
        inputParameter.SqlDbType = SqlDbType.VarChar;
        objCommand.Parameters.Add(inputParameter);

        SqlParameter inputParameter2 = new SqlParameter("@friendLogin", RequestedUsername);
        inputParameter2.Direction = ParameterDirection.Input;
        inputParameter2.SqlDbType = SqlDbType.VarChar;
        objCommand.Parameters.Add(inputParameter2);

        DataSet ds = db.GetDataSetUsingCmdObj(objCommand);

        //record was returned. person is a friend
        //finds list of persons friends and returns it as an arraylist
        if (ds.Tables[0].Rows.Count != 0)
        {
            db = new DBConnect();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_GetFriends";
            inputParameter = new SqlParameter("@username", RequestedUsername);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);
            ds = db.GetDataSetUsingCmdObj(objCommand);

            ArrayList profiles = new ArrayList();
            UserAccount profile;

            foreach (DataRow record in ds.Tables[0].Rows)
            {
                profile = new UserAccount();
                profile.Name = record["Name"].ToString();
                profile.ProfilePhotoURL = record["ProfilePhotoURL"].ToString();
                profiles.Add(profile);
            }
            return profiles;
        }
        else
        {
                //not friends with person being searched
                //returns empty arraylist
                ArrayList profiles = new ArrayList();
                return profiles;
        }
    } // end method

        // GET: api/FindByLocation/city/state
        [HttpGet("GetProfile/{requestingUsername}/{requestedUsername}/{verificationToken}/")]
        public UserAccount GetProfile(String RequestingUsername, String RequestedUsername, String VerificationToken)
        {

            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_CheckPrivacySettings";
            SqlParameter inputParameter = new SqlParameter("@loginID", RequestedUsername);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);
            DataSet ds = db.GetDataSetUsingCmdObj(objCommand);
            String profileprivacy = ds.Tables[0].Rows[0].ItemArray[1].ToString();
            String contactprivacy = ds.Tables[0].Rows[0].ItemArray[2].ToString();


            db = new DBConnect();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_CheckFriendOfFriends";
            inputParameter = new SqlParameter("@loginID1", RequestingUsername);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            SqlParameter inputParameter2 = new SqlParameter("@loginID2", RequestedUsername);
            inputParameter2.Direction = ParameterDirection.Input;
            inputParameter2.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter2);

            ds = db.GetDataSetUsingCmdObj(objCommand);
            String status;
            if (ds.Tables[0].Rows.Count != 0)
            {
                status = "Friend of friend";
            }


            //checks if friends
            db = new DBConnect();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_CheckFriends";
            inputParameter = new SqlParameter("@loginID", RequestingUsername);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            inputParameter2 = new SqlParameter("@friendLogin", RequestedUsername);
            inputParameter2.Direction = ParameterDirection.Input;
            inputParameter2.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter2);

            ds = db.GetDataSetUsingCmdObj(objCommand);

            
            if (ds.Tables[0].Rows.Count != 0)
            {
                status = "Friends";
            }
            else
            {
                status = "not friend";
            }

            


            db = new DBConnect();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_GetUserID";
            inputParameter = new SqlParameter("@email", RequestedUsername);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);
            ds = db.GetDataSetUsingCmdObj(objCommand);


            UserAccount profile = new UserAccount();
            if (status.Equals("Friends") || (status.Equals("Friend of friend") && !profileprivacy.Equals("1") && !contactprivacy.Equals("1")) || (status.Equals("not friend") && profileprivacy.Equals("3") && contactprivacy.Equals("3")))
            {
                foreach (DataRow record in ds.Tables[0].Rows)
                {                    
                    profile.Name = record["Name"].ToString();
                    profile.Address = record["Address"].ToString();
                    profile.PhoneNumber = record["PhoneNumber"].ToString();
                    profile.City = record["City"].ToString();
                    profile.State = record["State"].ToString();
                    profile.Organization = record["Organization"].ToString();
                    profile.ProfilePhotoURL = record["ProfilePhotoURL"].ToString();                    
                }
                return profile;
            }
            else
            {
                //invalid permissons
                if ((status.Equals("Friend of friend") && profileprivacy.Equals("1") && contactprivacy.Equals("1")) || (status.Equals("not friend") && !profileprivacy.Equals("3") && !contactprivacy.Equals("3")))
                {
                    profile = new UserAccount();
                    return profile;
                }

                else if ((status.Equals("Friend of friend") && profileprivacy.Equals("1")) || status.Equals("not friend") && !profileprivacy.Equals("3"))
                {
                    foreach (DataRow record in ds.Tables[0].Rows)
                    {                        
                        profile.LoginID = record["LoginID"].ToString();
                        profile.Name = record["Name"].ToString();
                        profile.Address = record["Address"].ToString();
                        profile.PhoneNumber = record["PhoneNumber"].ToString();
                        //profile.City = record["City"].ToString();
                        //profile.State = record["State"].ToString();
                        //profile.Organization = record["Organization"].ToString();
                        profile.ProfilePhotoURL = record["ProfilePhotoURL"].ToString();                        
                    }
                    return profile;
                }
                else
                {
                    foreach (DataRow record in ds.Tables[0].Rows)
                    {                        
                        profile.Name = record["Name"].ToString();
                        //profile.Address = record["Address"].ToString();
                        //profile.PhoneNumber = record["PhoneNumber"].ToString();
                        profile.City = record["City"].ToString();
                        profile.State = record["State"].ToString();
                        profile.Organization = record["Organization"].ToString();
                        profile.ProfilePhotoURL = record["ProfilePhotoURL"].ToString();
                        
                    }
                    return profile;
                }
            }
            
            



        } // end method

        // GET: api/FindByLocation/city/state
        [HttpGet("GetPhotos/{requestingUsername}/{requestedUsername}/{verificationToken}/")]
        public List<Photo> GetPhotos(String RequestingUsername, String RequestedUsername, String VerificationToken)
        {

            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_CheckPrivacySettings";
            SqlParameter inputParameter = new SqlParameter("@loginID", RequestedUsername);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);
            DataSet ds = db.GetDataSetUsingCmdObj(objCommand);
            String photoprivacy = ds.Tables[0].Rows[0].ItemArray[0].ToString();            

            db = new DBConnect();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_CheckFriendOfFriends";
            inputParameter = new SqlParameter("@loginID1", RequestingUsername);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            SqlParameter inputParameter2 = new SqlParameter("@loginID2", RequestedUsername);
            inputParameter2.Direction = ParameterDirection.Input;
            inputParameter2.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter2);

            ds = db.GetDataSetUsingCmdObj(objCommand);
            String status;
            if (ds.Tables[0].Rows.Count != 0)
            {
                status = "Friend of friend";
            }


            //checks if friends
            db = new DBConnect();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_CheckFriends";
            inputParameter = new SqlParameter("@loginID", RequestingUsername);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            inputParameter2 = new SqlParameter("@friendLogin", RequestedUsername);
            inputParameter2.Direction = ParameterDirection.Input;
            inputParameter2.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter2);

            ds = db.GetDataSetUsingCmdObj(objCommand);


            if (ds.Tables[0].Rows.Count != 0)
            {
                status = "Friends";
            }
            else
            {
                status = "not friend";
            }




            db = new DBConnect();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_GetPhotos";
            inputParameter = new SqlParameter("@loginID", RequestedUsername);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);
            ds = db.GetDataSetUsingCmdObj(objCommand);

            List<Photo> pics = new List<Photo>();
            Photo pic;

            if (status.Equals("Friends") || (status.Equals("Friend of friend") && !photoprivacy.Equals("1")) || (status.Equals("not friend") && photoprivacy.Equals("3")))
            {
                foreach (DataRow record in ds.Tables[0].Rows)
                {
                    pic = new Photo();
                    pic.LoginID = record["LoginID"].ToString();
                    pic.PhotoURL = record["PhotoURL"].ToString();
                    pic.PhotoDescription = record["PhotoDescription"].ToString();
                    pic.Album = record["Album"].ToString();
                    pics.Add(pic);
                }
                return pics;
            }
            else
            {
                return pics;
            }

        } // end method

        // GET: api/FindByLocation/city/state
        [HttpGet("GetNewsFeed/{requestingUsername}/{requestedUsername}/{verificationToken}/")]
        public List<NewsFeed> GetNewsFeed(String RequestingUsername, String RequestedUsername, String VerificationToken)
        {

            DBConnect db = new DBConnect();
            SqlCommand objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_CheckPrivacySettings";
            SqlParameter inputParameter = new SqlParameter("@loginID", RequestedUsername);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);
            DataSet ds = db.GetDataSetUsingCmdObj(objCommand);
            String profileprivacy = ds.Tables[0].Rows[0].ItemArray[1].ToString();

            db = new DBConnect();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_CheckFriendOfFriends";
            inputParameter = new SqlParameter("@loginID1", RequestingUsername);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            SqlParameter inputParameter2 = new SqlParameter("@loginID2", RequestedUsername);
            inputParameter2.Direction = ParameterDirection.Input;
            inputParameter2.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter2);

            ds = db.GetDataSetUsingCmdObj(objCommand);
            String status;
            if (ds.Tables[0].Rows.Count != 0)
            {
                status = "Friend of friend";
            }


            //checks if friends
            db = new DBConnect();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_CheckFriends";
            inputParameter = new SqlParameter("@loginID", RequestingUsername);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);

            inputParameter2 = new SqlParameter("@friendLogin", RequestedUsername);
            inputParameter2.Direction = ParameterDirection.Input;
            inputParameter2.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter2);

            ds = db.GetDataSetUsingCmdObj(objCommand);


            if (ds.Tables[0].Rows.Count != 0)
            {
                status = "Friends";
            }
            else
            {
                status = "not friend";
            }

            db = new DBConnect();
            objCommand = new SqlCommand();
            objCommand.CommandType = CommandType.StoredProcedure;
            objCommand.CommandText = "TP_GetNewsfeed";
            inputParameter = new SqlParameter("@loginID", RequestedUsername);
            inputParameter.Direction = ParameterDirection.Input;
            inputParameter.SqlDbType = SqlDbType.VarChar;
            objCommand.Parameters.Add(inputParameter);
            ds = db.GetDataSetUsingCmdObj(objCommand);

            List<NewsFeed> newsfeed = new List<NewsFeed>();
            NewsFeed post;

            if (status.Equals("Friends") || (status.Equals("Friend of friend") && !profileprivacy.Equals("1")) || (status.Equals("not friend") && profileprivacy.Equals("3")))
            {
                foreach (DataRow record in ds.Tables[0].Rows)
                {
                    post = new NewsFeed();
                    post.LoginID = record["LoginID"].ToString();
                    post.PosterID = record["PosterID"].ToString();
                    post.Message = record["Message"].ToString();                    
                    newsfeed.Add(post);
                }
                return newsfeed;
            }
            else
            {
                return newsfeed;
            }


        } // end method
        // end private services

        // POST: api/SocialNetworkService
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }
        
        // PUT: api/SocialNetworkService/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }
        
        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }

    } // end class
} // end namespace
