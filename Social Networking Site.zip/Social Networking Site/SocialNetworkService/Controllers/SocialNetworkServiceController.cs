﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

using System.Data;              // import needed for DataSet and other data classes
using System.Data.SqlClient;    // import needed for ADO.NET classes
using Utilities;                // import needed for DBConnect class
using Newtonsoft.Json.Serialization;

namespace SocialNetworkService.Controllers
{
    [Produces("application/json")]
    //[Route("api/SocialNetworkService")]
    [Route("api/[controller]/")]
    public class SocialNetworkServiceController : Controller
    {
        // public services
        // GET: api/FindByName/name
        [HttpGet("FindUsersByName/{name}")]
        public List<UserAccount> FindUsersByName(string name)
        {
            DBConnect objDB = new DBConnect();
            DataSet ds = objDB.GetDataSet("SELECT * FROM TP_UserAccounts WHERE Name ='" + name + "';");
            List<UserAccount> profiles = new List<UserAccount>();
            UserAccount profile;

            foreach (DataRow record in ds.Tables[0].Rows)
            {
                profile = new UserAccount();
                profile.Name = record["Name"].ToString();
                profile.City = record["City"].ToString();
                profile.State = record["State"].ToString();
                profile.Organization = record["Organization"].ToString();
                profile.ProfilePhotoURL = record["ProfilePhotoURL"].ToString();
                profiles.Add(profile);
            }

            return profiles;
        } // end method

        // GET: api/FindUsersByLocation/city/state
        [HttpGet("FindUsersByLocation/{city}/{state}/")]
        public List<UserAccount> FindUsersByLocation(string city, string state)
        {
            DBConnect objDB = new DBConnect();
            DataSet ds = objDB.GetDataSet("SELECT * FROM TP_UserAccounts WHERE City = '" + city + "' AND State = '" + state + "';");
            List<UserAccount> profiles = new List<UserAccount>();
            UserAccount profile;

            foreach (DataRow record in ds.Tables[0].Rows)
            {
                profile = new UserAccount();
                profile.Name = record["Name"].ToString();
                profile.City = record["City"].ToString();
                profile.State = record["State"].ToString();
                profile.Organization = record["Organization"].ToString();
                profile.ProfilePhotoURL = record["ProfilePhotoURL"].ToString();
                profiles.Add(profile);
            }

            return profiles;
        } // end method

        // GET: api/FindUsersByOrganization/organization
        [HttpGet("FindUsersByOrganization/{organization}")]
        public List<UserAccount> FindUsersByOrganization(string organization)
        {
            DBConnect objDB = new DBConnect();
            DataSet ds = objDB.GetDataSet("SELECT * FROM TP_UserAccounts WHERE Organization ='" + organization + "';");
            List<UserAccount> profiles = new List<UserAccount>();
            UserAccount profile;

            foreach (DataRow record in ds.Tables[0].Rows)
            {
                profile = new UserAccount();
                profile.Name = record["Name"].ToString();
                profile.City = record["City"].ToString();
                profile.State = record["State"].ToString();
                profile.Organization = record["Organization"].ToString();
                profile.ProfilePhotoURL = record["ProfilePhotoURL"].ToString();
                profiles.Add(profile);
            }

            return profiles;
        } // end method
        // end public services

        //// private services
        //// GET: api/GetFriend/requestingUsername/requestedUsername/verificationToken
        //[HttpGet("GetFriends/{requestingUsername}/{requestedUsername}/{verificationToken}/")]
        //public List<Friend> GetFriends(string requestingUsername, string requestedUsername, string verificationToken)
        //{
        //    DBConnect objDB = new DBConnect();
        //    DataSet ds = objDB.GetDataSet("SELECT * FROM TP_Friends INNER JOIN TP_UserAccounts ON TP_Friends.LoginID = '" + city + "' AND State = '" + state + "';");
        //    List<UserAccount> profiles = new List<UserAccount>();
        //    UserAccount profile;

        //    foreach (DataRow record in ds.Tables[0].Rows)
        //    {
        //        profile = new UserAccount();
        //        profile.Name = record["Name"].ToString();
        //        profile.City = record["City"].ToString();
        //        profile.State = record["State"].ToString();
        //        profile.Organization = record["Organization"].ToString();
        //        profile.ProfilePhotoURL = record["ProfilePhotoURL"].ToString();
        //        profiles.Add(profile);
        //    }

        //    return profiles;
        //} // end method

        //// GET: api/FindByLocation/city/state
        //[HttpGet("GetArrFriends/{city}/{state}/")]
        //public Friend[] GetArrFriends(string RequestingUsername, string RequestedUsername, string VerificationToken)
        //{
        //    DBConnect objDB = new DBConnect();
        //    DataSet ds = objDB.GetDataSet("SELECT * FROM TP_UserAccounts WHERE City = '" + city + "' AND State = '" + state + "';");
        //    List<UserAccount> profiles = new List<UserAccount>();
        //    UserAccount profile;

        //    foreach (DataRow record in ds.Tables[0].Rows)
        //    {
        //        profile = new UserAccount();
        //        profile.Name = record["Name"].ToString();
        //        profile.City = record["City"].ToString();
        //        profile.State = record["State"].ToString();
        //        profile.Organization = record["Organization"].ToString();
        //        profile.ProfilePhotoURL = record["ProfilePhotoURL"].ToString();
        //        profiles.Add(profile);
        //    }

        //    return profiles;
        //} // end method

        //// GET: api/FindByLocation/city/state
        //[HttpGet("GetProfile/{city}/{state}/")]
        //public UserAccount GetProfile(String RequestingUsername, String RequestedUsername, String VerificationToken)
        //{
        //    DBConnect objDB = new DBConnect();
        //    DataSet ds = objDB.GetDataSet("SELECT * FROM TP_UserAccounts WHERE City = '" + city + "' AND State = '" + state + "';");
        //    List<UserAccount> profiles = new List<UserAccount>();
        //    UserAccount profile;

        //    foreach (DataRow record in ds.Tables[0].Rows)
        //    {
        //        profile = new UserAccount();
        //        profile.Name = record["Name"].ToString();
        //        profile.City = record["City"].ToString();
        //        profile.State = record["State"].ToString();
        //        profile.Organization = record["Organization"].ToString();
        //        profile.ProfilePhotoURL = record["ProfilePhotoURL"].ToString();
        //        profiles.Add(profile);
        //    }

        //    return profiles;
        //} // end method

        //// GET: api/FindByLocation/city/state
        //[HttpGet("GetPhotos/{city}/{state}/")]
        //public Photo GetPhotos(String RequestingUsername, String RequestedUsername, String VerificationToken)
        //{
        //    DBConnect objDB = new DBConnect();
        //    DataSet ds = objDB.GetDataSet("SELECT * FROM TP_UserAccounts WHERE City = '" + city + "' AND State = '" + state + "';");
        //    List<UserAccount> profiles = new List<UserAccount>();
        //    UserAccount profile;

        //    foreach (DataRow record in ds.Tables[0].Rows)
        //    {
        //        profile = new UserAccount();
        //        profile.Name = record["Name"].ToString();
        //        profile.City = record["City"].ToString();
        //        profile.State = record["State"].ToString();
        //        profile.Organization = record["Organization"].ToString();
        //        profile.ProfilePhotoURL = record["ProfilePhotoURL"].ToString();
        //        profiles.Add(profile);
        //    }

        //    return profiles;
        //} // end method

        //// GET: api/FindByLocation/city/state
        //[HttpGet("GetNewsFeed/{city}/{state}/")]
        //public NewsFeed GetNewsFeed(String RequestingUsername, String RequestedUsername, String VerificationToken)
        //{
        //    DBConnect objDB = new DBConnect();
        //    DataSet ds = objDB.GetDataSet("SELECT * FROM TP_UserAccounts WHERE City = '" + city + "' AND State = '" + state + "';");
        //    List<UserAccount> profiles = new List<UserAccount>();
        //    UserAccount profile;

        //    foreach (DataRow record in ds.Tables[0].Rows)
        //    {
        //        profile = new UserAccount();
        //        profile.Name = record["Name"].ToString();
        //        profile.City = record["City"].ToString();
        //        profile.State = record["State"].ToString();
        //        profile.Organization = record["Organization"].ToString();
        //        profile.ProfilePhotoURL = record["ProfilePhotoURL"].ToString();
        //        profiles.Add(profile);
        //    }

        //    return profiles;
        //} // end method
        // end private services

        // POST: api/SocialNetworkService
        [HttpPost]
        public void Post([FromBody]string value)
        {
        }
        
        // PUT: api/SocialNetworkService/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody]string value)
        {
        }
        
        // DELETE: api/ApiWithActions/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }

    } // end class
} // end namespace
