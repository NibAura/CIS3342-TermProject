﻿CREATE PROCEDURE [dbo].[TP_Login]
	@email varchar(50),
	@password varchar(50)
AS
	SELECT * from TP_UserAccounts where LoginID=@email and Password=@password
